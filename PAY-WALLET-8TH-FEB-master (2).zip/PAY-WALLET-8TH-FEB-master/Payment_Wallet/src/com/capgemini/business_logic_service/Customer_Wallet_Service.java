package com.capgemini.business_logic_service;

import java.math.BigDecimal;

import com.capgemini.beans.Customer;
import com.capgemini.exceptions.CustomerNameCanNotBeNullExceptions;
import com.capgemini.exceptions.DuplicateMobileNumberExceptions;
import com.capgemini.exceptions.InsufficientBalanceExceptions;
import com.capgemini.exceptions.MobileNumberCanNotBeNullExceptions;
import com.capgemini.exceptions.MobileNumberDoesNotExistExceptions;

public interface Customer_Wallet_Service {
	
	public Customer CreateCustomerAccount(String Customer_Name, String Customer_MobileNo, BigDecimal Customer_Balance) throws DuplicateMobileNumberExceptions, MobileNumberCanNotBeNullExceptions, CustomerNameCanNotBeNullExceptions;
	public Customer ShowCustomerBalance(String Customer_MobileNo) throws MobileNumberDoesNotExistExceptions, MobileNumberCanNotBeNullExceptions;
	public Customer FundTransfer(String sourceMobileNo, String targetMobileNo, BigDecimal amount) throws MobileNumberDoesNotExistExceptions, MobileNumberCanNotBeNullExceptions;
	public Customer DepositAmount(String Customer_MobileNo, BigDecimal amount) throws MobileNumberDoesNotExistExceptions, MobileNumberCanNotBeNullExceptions;
	public Customer WithdrawAmount(String Customer_MobileNo, BigDecimal amount) throws MobileNumberDoesNotExistExceptions, MobileNumberCanNotBeNullExceptions, InsufficientBalanceExceptions;
	

}
 