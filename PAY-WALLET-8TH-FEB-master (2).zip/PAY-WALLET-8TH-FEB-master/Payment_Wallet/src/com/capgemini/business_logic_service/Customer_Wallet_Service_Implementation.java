package com.capgemini.business_logic_service;

import java.math.BigDecimal;
import java.util.regex.Pattern;

import com.capgemini.beans.Customer;
import com.capgemini.beans.Wallet;
import com.capgemini.exceptions.CustomerNameCanNotBeNullExceptions;
import com.capgemini.exceptions.DuplicateMobileNumberExceptions;
import com.capgemini.exceptions.InsufficientBalanceExceptions;
import com.capgemini.exceptions.MobileNumberCanNotBeNullExceptions;
import com.capgemini.exceptions.MobileNumberDoesNotExistExceptions;
import com.capgemini.repository.Customer_Wallet_Repository;
import com.capgemini.repository.Customer_Wallet_Repository_Implementation;

public class Customer_Wallet_Service_Implementation implements Customer_Wallet_Service{
	
	
	Customer_Wallet_Repository cust_wallet_repo = new Customer_Wallet_Repository_Implementation();
	Wallet wallet;
	




	@SuppressWarnings("unused")
	@Override
	public Customer CreateCustomerAccount(String Customer_Name, String Customer_MobileNo, BigDecimal Customer_Balance) throws DuplicateMobileNumberExceptions, MobileNumberCanNotBeNullExceptions, CustomerNameCanNotBeNullExceptions
	{
		Customer customer = new Customer(Customer_Name, Customer_MobileNo, new Wallet(Customer_Balance));
		
		
		
		if(Customer_MobileNo.length()!=10)
		{
			System.out.println("NOT A VALID MOBILE NUMBER");
		}
		
		if(Pattern.compile( "[0-9]" ).matcher( Customer_Name ).find())
		{
			System.out.println("NOT A VALID NAME");
		}
		
		if(Customer_MobileNo == null)
		{
			throw new MobileNumberCanNotBeNullExceptions();
		}
		
		if(Customer_Name == null)
		{
			throw new CustomerNameCanNotBeNullExceptions();
		}
		
		if(cust_wallet_repo.FindOneCustomer(Customer_MobileNo)!=null)
		{
			throw new DuplicateMobileNumberExceptions();
		}
		
		cust_wallet_repo.Save_Customer(customer);
		return customer;
	
	}


	@Override
	public Customer DepositAmount(String Customer_MobileNo, BigDecimal amount) throws MobileNumberDoesNotExistExceptions, MobileNumberCanNotBeNullExceptions{
        Customer customer = cust_wallet_repo.FindOneCustomer(Customer_MobileNo);
        if(customer == null)
		{
			throw new MobileNumberDoesNotExistExceptions();
		}
        
        if(Customer_MobileNo == null)
		{
			throw new MobileNumberCanNotBeNullExceptions();
		}
        
		wallet.setCustomer_Balance(wallet.getCustomer_Balance().add(amount));
		cust_wallet_repo.Save_Customer(customer);
		return customer; 
	}


	@Override
	public Customer WithdrawAmount(String Customer_MobileNo, BigDecimal amount)  throws MobileNumberDoesNotExistExceptions, MobileNumberCanNotBeNullExceptions, InsufficientBalanceExceptions{
        Customer customer = cust_wallet_repo.FindOneCustomer(Customer_MobileNo);
        if(customer == null)
		{
			throw new MobileNumberDoesNotExistExceptions();
		}
        
        if(Customer_MobileNo == null)
		{
			throw new MobileNumberCanNotBeNullExceptions();
		}
        
        
        wallet.setCustomer_Balance(wallet.getCustomer_Balance().subtract(amount));
		cust_wallet_repo.Save_Customer(customer);
		return customer;
	}
	
	
	@Override
	public Customer ShowCustomerBalance(String Customer_MobileNo) throws MobileNumberDoesNotExistExceptions, MobileNumberCanNotBeNullExceptions {
		Customer customer = cust_wallet_repo.FindOneCustomer(Customer_MobileNo);
		if(customer == null)
		{
			throw new MobileNumberDoesNotExistExceptions();
		}
        
        if(Customer_MobileNo == null)
		{
			throw new MobileNumberCanNotBeNullExceptions();
		}
        
		return cust_wallet_repo.FindOneCustomer(Customer_MobileNo);
	}


	@Override
	public Customer FundTransfer(String sourceMobileNo, String targetMobileNo, BigDecimal amount) throws MobileNumberDoesNotExistExceptions, MobileNumberCanNotBeNullExceptions{
		Customer customer1 = cust_wallet_repo.FindOneCustomer(sourceMobileNo);
		Customer customer2 = cust_wallet_repo.FindOneCustomer(targetMobileNo);
    	
		customer1.getCustomer_Wallet().setCustomer_Balance(customer1.getCustomer_Wallet().getCustomer_Balance().subtract(amount));
		customer2.getCustomer_Wallet().setCustomer_Balance(customer2.getCustomer_Wallet().getCustomer_Balance().add(amount));
		return customer2;
    	
	}
	
	
	
	
	
	
	
	
	
	}
	
