package com.capgemini.test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import java.math.BigDecimal;

import org.junit.Before;

import com.capgemini.business_logic_service.Customer_Wallet_Service;
import com.capgemini.business_logic_service.Customer_Wallet_Service_Implementation;
import com.capgemini.exceptions.CustomerNameCanNotBeNullExceptions;
import com.capgemini.exceptions.DuplicateMobileNumberExceptions;
import com.capgemini.exceptions.InsufficientBalanceExceptions;
import com.capgemini.exceptions.MobileNumberCanNotBeNullExceptions;
import com.capgemini.exceptions.MobileNumberDoesNotExistExceptions;
import com.capgemini.repository.Customer_Wallet_Repository;
import com.capgemini.repository.Customer_Wallet_Repository_Implementation;

public class Customer_Wallet_Service_Test {
	
	
	Customer_Wallet_Repository cust_wallet_repo=new Customer_Wallet_Repository_Implementation();
	Customer_Wallet_Service cust_wallet_serv=new Customer_Wallet_Service_Implementation();

		@Before
		public void setUp() throws Exception {
		}
		
			
		@Test(expected=com.capgemini.exceptions.DuplicateMobileNumberExceptions.class)
		public void test() throws DuplicateMobileNumberExceptions, MobileNumberCanNotBeNullExceptions, CustomerNameCanNotBeNullExceptions
		{
			cust_wallet_serv.CreateCustomerAccount("Ravi", "1",new BigDecimal("10000.0"));
			cust_wallet_serv.CreateCustomerAccount("Ravi", "1",new BigDecimal("10000.0"));
			
		}
		@Test(expected=com.capgemini.exceptions.MobileNumberDoesNotExistExceptions.class)
		public void test1() throws MobileNumberDoesNotExistExceptions, MobileNumberCanNotBeNullExceptions, InsufficientBalanceExceptions
		{
			cust_wallet_serv.WithdrawAmount("7",new BigDecimal("20000"));
			
			
		}
		@Test
		public void test3() throws DuplicateMobileNumberExceptions, MobileNumberCanNotBeNullExceptions, CustomerNameCanNotBeNullExceptions 
		{
			cust_wallet_serv.CreateCustomerAccount("Ravi", "1",new BigDecimal("10000.0"));
			
			
		}
	}
	
	

