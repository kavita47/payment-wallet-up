package com.capgemini.view;

import java.math.BigDecimal;

import com.capgemini.business_logic_service.Customer_Wallet_Service;
import com.capgemini.business_logic_service.Customer_Wallet_Service_Implementation;
import com.capgemini.exceptions.CustomerNameCanNotBeNullExceptions;
import com.capgemini.exceptions.DuplicateMobileNumberExceptions;
import com.capgemini.exceptions.InsufficientBalanceExceptions;
import com.capgemini.exceptions.MobileNumberCanNotBeNullExceptions;
import com.capgemini.exceptions.MobileNumberDoesNotExistExceptions;

public class Customer_View_Application {

	public static void main(String[] args) throws CustomerNameCanNotBeNullExceptions, DuplicateMobileNumberExceptions, InsufficientBalanceExceptions, MobileNumberCanNotBeNullExceptions, MobileNumberDoesNotExistExceptions{
		
		Customer_Wallet_Service cust_wallet_serv = new Customer_Wallet_Service_Implementation();
		
		cust_wallet_serv.CreateCustomerAccount("ADITYA", "1234567891", new BigDecimal("10000"));
		cust_wallet_serv.CreateCustomerAccount("ARMAN", "2222223456", new BigDecimal("15000"));
		
		System.out.println(cust_wallet_serv.ShowCustomerBalance("1234567891").getCustomer_Wallet().getCustomer_Balance());
		System.out.println(cust_wallet_serv.ShowCustomerBalance("2222223456").getCustomer_Wallet().getCustomer_Balance());

		cust_wallet_serv.DepositAmount("1234567891",new BigDecimal("30000"));
		cust_wallet_serv.DepositAmount("2222223456",new BigDecimal("40000"));

		System.out.println(cust_wallet_serv.ShowCustomerBalance("1234567891").getCustomer_Wallet().getCustomer_Balance());
		System.out.println(cust_wallet_serv.ShowCustomerBalance("2222223456").getCustomer_Wallet().getCustomer_Balance());

		cust_wallet_serv.WithdrawAmount("1234567891",new BigDecimal("20000"));
		cust_wallet_serv.WithdrawAmount("2222223456",new BigDecimal("20000"));

		System.out.println(cust_wallet_serv.ShowCustomerBalance("1234567891").getCustomer_Wallet().getCustomer_Balance());
		System.out.println(cust_wallet_serv.ShowCustomerBalance("2222223456").getCustomer_Wallet().getCustomer_Balance());

		cust_wallet_serv.FundTransfer("1234567891", "2222223456",new BigDecimal("20000"));

		System.out.println(cust_wallet_serv.ShowCustomerBalance("1234567891").getCustomer_Wallet().getCustomer_Balance());
		System.out.println(cust_wallet_serv.ShowCustomerBalance("2222223456").getCustomer_Wallet().getCustomer_Balance());
		
		
	}

}


