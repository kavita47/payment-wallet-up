package com.capgemini.exceptions;

public class MobileNumberDoesNotExistExceptions extends Exception {

}
