package com.capgemini.exceptions;

public class MobileNumberCanNotBeNullExceptions extends Exception {

}
