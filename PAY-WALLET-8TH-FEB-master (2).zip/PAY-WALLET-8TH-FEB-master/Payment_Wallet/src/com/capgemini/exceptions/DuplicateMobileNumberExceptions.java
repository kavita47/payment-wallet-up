package com.capgemini.exceptions;

public class DuplicateMobileNumberExceptions extends Exception{

}
