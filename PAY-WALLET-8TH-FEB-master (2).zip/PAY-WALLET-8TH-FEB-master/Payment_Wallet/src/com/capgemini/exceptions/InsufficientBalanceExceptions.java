package com.capgemini.exceptions;

public class InsufficientBalanceExceptions extends Exception {

}
