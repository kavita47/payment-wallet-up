package com.capgemini.exception;

public class PhoneNoDoesNotExist extends Exception {

}
